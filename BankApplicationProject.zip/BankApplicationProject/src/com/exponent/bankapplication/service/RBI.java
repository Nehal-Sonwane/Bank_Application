package com.exponent.bankapplication.service;

public interface RBI {
	
	public void createAccount();
	
	public void showAccountDetails();
	
	public void showAccountBalance();
	
	public void withdrawAmount();
	
	public void depositeAmount();
	
	public void updatAccountDetails();

}
